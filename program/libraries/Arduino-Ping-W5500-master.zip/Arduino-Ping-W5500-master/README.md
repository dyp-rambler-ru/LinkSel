# Arduino-Ping-W5500
W5500 version of ICMP ping library for the Arduino by Blake Foster

Uses Adafruit's Ethernet 2 library for W5500
